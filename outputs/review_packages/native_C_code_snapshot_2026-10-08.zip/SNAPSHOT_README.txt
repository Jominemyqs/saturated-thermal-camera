Native C inspection snapshot, before the non-saturation-mask experiment.
Revision: d28f8d86f944728bb57fa0926a4b66b10f055aba
Not standalone runnable: dataset and other repository imports intentionally omitted.
Begin with scripts/53_thermal_matched_projection_gp.py; covariance and sampling helpers are under src/.
The frozen config includes historical labels; the executed native pilot used two development cases and area weights.
Development CSVs record simulation-based coefficient calibration; no copied file was edited.
MANIFEST.json contains individual SHA-256 hashes and pre-experiment working-tree status.
